$ = jQuery;
$(document).ready(function(){

$(".owl-carousel.owl-testimonial").owlCarousel({
items:2,
autoPlay : false,
rtl:true,
pagination:false,
loop:true,
navigation:true,
navigationText:['<i class="fa fa-angle-left"></i>','<i class="fa fa-angle-right"></i>'],
itemsTablet: [1000,1], 
itemsMobile : [750,1],
itemsDesktop: [1200,2],

});
$("a.fancybox").fancybox();

})